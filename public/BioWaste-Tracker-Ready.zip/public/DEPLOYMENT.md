# BioWaste Tracker - Deployment Instructions

To make this website permanent and accessible at a public URL (e.g., `biowaste-tracker.vercel.app`), follow these steps:

## 1. Setup a Database (Permanent)
Since this sandbox database is temporary, you need a permanent PostgreSQL database.
*   Go to **[Neon.tech](https://neon.tech)** (Free tier is great).
*   Create a new project and copy the **Connection String** (looks like `postgres://user:pass@host/db`).

## 2. Prepare the Code
1.  **Download the ZIP** from the link below.
2.  **Upload to GitHub**: Create a new private or public repository on GitHub and push these files there.

## 3. Deploy to Vercel
1.  Go to **[Vercel.com](https://vercel.com)** and sign in with GitHub.
2.  Click **"Add New"** > **"Project"**.
3.  Import your GitHub repository.
4.  **Environment Variables**: This is the most important step. Add these 3 variables:
    *   `DATABASE_URL` = (Paste your Neon.tech connection string here)
    *   `AUTH_SECRET` = (Type any long random text, e.g., `a1b2c3d4e5f6g7h8i9j0`)
    *   `AUTH_TRUST_HOST` = `true`
5.  Click **Deploy**.

## 4. Final Step: Initialize Database
Once deployed, you need to create the tables in your new database:
1.  On your computer, open the project folder in a terminal.
2.  Run `npm install`.
3.  Run `npx drizzle-kit push`.
4.  (Optional) To get the demo users back, run the seed script: `npx tsx src/app/api/seed/route.ts` (or use the "Seed Demo Data" button if you added it to your UI).

---

### Your Deployment Package:
**[📥 Download Final Zip for Deployment](https://3000-ioafhyjxbhrjsv6lczldc.e2b.app/biowaste-tracker-final.zip)**
**[🔗 Current Sandbox Link (Temporary)](https://3000-ioafhyjxbhrjsv6lczldc.e2b.app)**
